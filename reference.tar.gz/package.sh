#!/bin/bash

/bin/tar czf submission.tar.gz run.sh compile.sh package.sh README src
